from flask import Flask, render_template as rt, request
import os
app = Flask(__name__)

@app.route('/', methods=['POST', 'GET'])
def shutdown():
    if request.method == 'POST':
        return os.system("shutdown /s /t 5")
    return rt('index.html')

if __name__ == "__main__":
    app.run(debug=True)

